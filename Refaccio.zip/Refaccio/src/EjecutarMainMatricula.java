/*
 * @author: Jose Manuel Alique Rodriguez
 * @version: version 1.0
 */

public class EjecutarMainMatricula {
    static Matricula matricula = new Matricula();
    static Class clase = matricula.getClass();

    public static void main(String[] args) {

    }
}